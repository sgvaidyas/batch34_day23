﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace day23_products
{
    public partial class Form1 : Form
    {
        SqlConnection conn;
        
        public Form1()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string query = "select TABLE_NAME from INFORMATION_SCHEMA.TABLES";
            try
            {

                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                cbtables.DataSource = ds.Tables[0];
                // cbtables.DisplayMember = ds.Tables[0].Columns[0].ToString();
                cbtables.DisplayMember = ds.Tables[0].Columns["Table_name"].ToString();
                conn.Close();
            }
            catch(Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }

        private void btndisplay_Click(object sender, EventArgs e)
        {
            string tabname = cbtables.Text;
            string query = "select * from " + tabname;

            SqlDataAdapter da = new SqlDataAdapter(query,conn);
            DataSet ds = new DataSet();
            da.Fill(ds);

            dgcontent.DataSource = ds.Tables[0] ;
        }
    }
}
