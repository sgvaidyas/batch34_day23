﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace day23_products
{
    public partial class order_mapping : Form
    {
        SqlConnection conn;
        int orderid;
        public order_mapping()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }
        private void getorderid()
        {
            string query = "select max(oid) from orders";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                orderid = (int)cmd.ExecuteScalar()+1;
                lblorderid.Text = orderid.ToString();
                conn.Close();
            }
            catch(Exception ob)
            {
                MessageBox.Show(ob.Message);
            }           
        }
        private void order_mapping_Load(object sender, EventArgs e)
        {
            getorderid();

            string query = "select * from Products";

            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(query,conn);
                DataSet ds = new DataSet();
                da.Fill(ds);

                cmbpid.DataSource = ds.Tables[0];
                cmbpid.ValueMember = ds.Tables[0].Columns[0].ToString();
                cmbpid.DisplayMember = ds.Tables[0].Columns[1].ToString() ;

                conn.Close();
            }
            catch(Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sample = cmbpid.Text +" : " + cmbpid.SelectedValue;
            MessageBox.Show(sample);
        }
    }
}
