﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CustomerDetails
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            InsertDetails ob = new InsertDetails();
            ob.Show();
            this.Hide();
        }

        private void btndisplay_Click(object sender, EventArgs e)
        {
            DisplayDetails ob = new DisplayDetails();
            ob.Show();
            this.Hide();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            SearchDetails ob = new SearchDetails();
            ob.Show();
            this.Hide();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            UpdateDetails ob = new UpdateDetails();
            ob.Show();
            this.Hide();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            DeleteDetails ob = new DeleteDetails();
            ob.Show();
            this.Hide();
        }

        protected override void OnClosed(EventArgs e)
        {
            if(MessageBox.Show("Closing app.Confirm?","Close Application",MessageBoxButtons.YesNo)== DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                this.Activate();
            }
        }

        private void insertToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void insertToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            InsertDetails ob = new InsertDetails();
            ob.Show();
            this.Hide();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            
        }

        private void insertToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }
    }
}
