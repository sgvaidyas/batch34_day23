﻿namespace CustomerDetails
{
    partial class UpdateDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelresult = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtcustid = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.dtdob = new System.Windows.Forms.DateTimePicker();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtcontact = new System.Windows.Forms.NumericUpDown();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.txtmessage = new System.Windows.Forms.TextBox();
            this.btnupdate = new System.Windows.Forms.Button();
            this.panelresult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtcustid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcontact)).BeginInit();
            this.SuspendLayout();
            // 
            // panelresult
            // 
            this.panelresult.Controls.Add(this.btnupdate);
            this.panelresult.Controls.Add(this.txtmessage);
            this.panelresult.Controls.Add(this.txtaddress);
            this.panelresult.Controls.Add(this.txtcontact);
            this.panelresult.Controls.Add(this.txtemail);
            this.panelresult.Controls.Add(this.dtdob);
            this.panelresult.Controls.Add(this.txtname);
            this.panelresult.Controls.Add(this.label7);
            this.panelresult.Controls.Add(this.label6);
            this.panelresult.Controls.Add(this.label5);
            this.panelresult.Controls.Add(this.label4);
            this.panelresult.Controls.Add(this.label3);
            this.panelresult.Controls.Add(this.label2);
            this.panelresult.Location = new System.Drawing.Point(48, 89);
            this.panelresult.Name = "panelresult";
            this.panelresult.Size = new System.Drawing.Size(620, 294);
            this.panelresult.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 182);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(126, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "CUSTOMER  MESSAGE";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(126, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "CUSTOMER  ADDRESS";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 119);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "CUSTOMER CONTACT";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "CUSTOMER EMAIL";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "CUSTOMER DOB";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "CUSTOMER NAME";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(482, 35);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 6;
            this.btnSearch.Text = "SEARCH";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtcustid
            // 
            this.txtcustid.Location = new System.Drawing.Point(278, 35);
            this.txtcustid.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.txtcustid.Name = "txtcustid";
            this.txtcustid.Size = new System.Drawing.Size(120, 20);
            this.txtcustid.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "PLEASE ENTER THE CUSTOMER ID";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(256, 12);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(200, 20);
            this.txtname.TabIndex = 6;
            // 
            // dtdob
            // 
            this.dtdob.Location = new System.Drawing.Point(256, 47);
            this.dtdob.Name = "dtdob";
            this.dtdob.Size = new System.Drawing.Size(200, 20);
            this.dtdob.TabIndex = 7;
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(256, 79);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(200, 20);
            this.txtemail.TabIndex = 8;
            // 
            // txtcontact
            // 
            this.txtcontact.Location = new System.Drawing.Point(256, 119);
            this.txtcontact.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.txtcontact.Name = "txtcontact";
            this.txtcontact.Size = new System.Drawing.Size(200, 20);
            this.txtcontact.TabIndex = 9;
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(256, 151);
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(200, 20);
            this.txtaddress.TabIndex = 10;
            // 
            // txtmessage
            // 
            this.txtmessage.Location = new System.Drawing.Point(256, 182);
            this.txtmessage.Multiline = true;
            this.txtmessage.Name = "txtmessage";
            this.txtmessage.Size = new System.Drawing.Size(285, 61);
            this.txtmessage.TabIndex = 11;
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(256, 262);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(75, 23);
            this.btnupdate.TabIndex = 12;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // UpdateDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelresult);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtcustid);
            this.Controls.Add(this.label1);
            this.Name = "UpdateDetails";
            this.Text = "UpdateDetails";
            this.Load += new System.EventHandler(this.UpdateDetails_Load);
            this.panelresult.ResumeLayout(false);
            this.panelresult.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtcustid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcontact)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelresult;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.NumericUpDown txtcustid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.TextBox txtmessage;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.NumericUpDown txtcontact;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.DateTimePicker dtdob;
        private System.Windows.Forms.TextBox txtname;
    }
}