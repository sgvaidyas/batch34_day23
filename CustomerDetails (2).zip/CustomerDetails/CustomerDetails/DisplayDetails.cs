﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CustomerDetails
{
    public partial class DisplayDetails : Form
    {
        SqlConnection conn;

        public DisplayDetails()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void DisplayDetails_Load(object sender, EventArgs e)
        {
            List<Customer> custdetails = new List<Customer>();
            try
            {
                string query = "select * from Customers";
                conn.Open();
                SqlCommand cmd = new SqlCommand(query,conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while(reader.Read())
                {
                    Customer c = new Customer();
                    c.CustomerId = int.Parse(reader[0].ToString());
                    c.CustomerName = reader[1].ToString();
                    c.CustomerDob = reader[2].ToString();
                    c.CustomerEmail = reader[3].ToString();
                    c.CustomerContact =Convert.ToInt64(reader[4].ToString());
                    c.CustomerAddress = reader[5].ToString();
                    c.CustomerMessage = reader[6].ToString();
                    custdetails.Add(c);
                }
                dgalldata.DataSource = custdetails;
                conn.Close();
            }
            catch(Exception ob)
            {
                MessageBox.Show("Cannot display details");
            }
        }

        private void btnmainmenu_Click(object sender, EventArgs e)
        {
            Dashboard ob = new Dashboard();
            ob.Show();
            this.Hide();
        }
    
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Dashboard ob = new Dashboard();
            ob.Show();
            base.OnFormClosed(e);
        }

    }
}
