﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace CustomerDetails
{
    public partial class UpdateDetails : Form
    {
        SqlConnection conn;
        public UpdateDetails()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            panelresult.Visible = false;
            string id = txtcustid.Value.ToString();
            string query = "select * from Customers where Customerid="+id;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query,conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    Customer c = new Customer();
                    c.CustomerId = int.Parse(reader[0].ToString());
                    c.CustomerName = reader[1].ToString();
                    c.CustomerDob =  reader[2].ToString();
                    c.CustomerEmail= reader[3].ToString();
                    c.CustomerContact = Convert.ToInt64(reader[4].ToString());
                    c.CustomerAddress =   reader[5].ToString();
                    c.CustomerMessage = reader[6].ToString();
                    updateme(c);
                }
                else
                    MessageBox.Show("Sorry the Cust id doesnt exist");

                conn.Close();
            }
            catch(Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }

        private void UpdateDetails_Load(object sender, EventArgs e)
        {
            panelresult.Visible = false;
        }
        private void updateme(Customer c)
        {
            txtname.Text = c.CustomerName;
            dtdob.Text = c.CustomerDob;
            txtemail.Text = c.CustomerEmail;
            txtcontact.Value = c.CustomerContact;
            txtaddress.Text = c.CustomerAddress;
            txtmessage.Text = c.CustomerMessage;
            panelresult.Visible = true;
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            string query;
            query = String.Format("update Customers set CustomerName = '{0}', CustomerDob = '{1}', CustomerEmail = '{2}',CustomerContact = {3}, CustomerAddress = '{4}',CustomerMessage = '{5}' where CustomerID = {6}", txtname.Text, dtdob.Text, txtemail.Text, txtcontact.Value, txtaddress.Text, txtmessage.Text, txtcustid.Value);

            MessageBox.Show(query);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record updated");
                conn.Close();
            }
            catch(Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }
    }
}
