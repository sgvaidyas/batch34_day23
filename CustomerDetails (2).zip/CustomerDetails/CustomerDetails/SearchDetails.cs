﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CustomerDetails
{
    public partial class SearchDetails : Form
    {
        SqlConnection conn;

        public SearchDetails()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            panelresult.Visible = false;
            string id = txtcustid.Value.ToString();
            try
            {
                conn.Open();
                string sql = "select * from Customers where Customerid="+id;
                SqlCommand cmd = new SqlCommand(sql,conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    Customer c = new Customer();
                    c.CustomerId = int.Parse(reader[0].ToString());
                    c.CustomerName = reader[1].ToString();
                    c.CustomerDob = reader[2].ToString();
                    c.CustomerEmail = reader[3].ToString();
                    c.CustomerContact = Convert.ToInt64(reader[4].ToString());
                    c.CustomerAddress = reader[5].ToString();
                    c.CustomerMessage = reader[6].ToString();
                    //MessageBox.Show(c.ToString());
                    lblname.Text = reader[1].ToString();
                    lbldob.Text = reader[2].ToString();
                    lblemail.Text = reader[3].ToString();
                    lblcontact.Text = reader[4].ToString();
                    lbladdress.Text = reader[5].ToString();
                    lblmessage.Text = reader[6].ToString();
                    panelresult.Visible = true;
                }
                else
                    MessageBox.Show("Customer id does not exist");
                conn.Close();
            }
            catch(Exception ob)
            {
                MessageBox.Show("Some issue with the connection");
            }
        }

        private void SearchDetails_Load(object sender, EventArgs e)
        {
            panelresult.Visible = false;
        }

        private void txtcustid_ValueChanged(object sender, EventArgs e)
        {
            panelresult.Visible = false;
        }
    }
}
