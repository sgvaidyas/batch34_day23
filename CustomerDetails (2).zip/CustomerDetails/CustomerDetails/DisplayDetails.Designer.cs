﻿namespace CustomerDetails
{
    partial class DisplayDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgalldata = new System.Windows.Forms.DataGridView();
            this.btnmainmenu = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgalldata)).BeginInit();
            this.SuspendLayout();
            // 
            // dgalldata
            // 
            this.dgalldata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgalldata.Location = new System.Drawing.Point(44, 39);
            this.dgalldata.Name = "dgalldata";
            this.dgalldata.Size = new System.Drawing.Size(716, 273);
            this.dgalldata.TabIndex = 0;
            // 
            // btnmainmenu
            // 
            this.btnmainmenu.Location = new System.Drawing.Point(23, 358);
            this.btnmainmenu.Name = "btnmainmenu";
            this.btnmainmenu.Size = new System.Drawing.Size(96, 34);
            this.btnmainmenu.TabIndex = 1;
            this.btnmainmenu.Text = "MAIN MENU";
            this.btnmainmenu.UseVisualStyleBackColor = true;
            this.btnmainmenu.Click += new System.EventHandler(this.btnmainmenu_Click);
            // 
            // DisplayDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnmainmenu);
            this.Controls.Add(this.dgalldata);
            this.Name = "DisplayDetails";
            this.Text = "DisplayDetails";
            this.Load += new System.EventHandler(this.DisplayDetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgalldata)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgalldata;
        private System.Windows.Forms.Button btnmainmenu;
    }
}